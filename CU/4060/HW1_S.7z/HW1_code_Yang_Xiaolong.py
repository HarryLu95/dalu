
print '''\nSTSCI 4060 HW1 Solution

Name: Xiaolong Yang

(10 points for good formatting and displaying comments)

***** Question 1 *****'''

print '''\nThis program is to use a format string and
a tuple to format and change a story. '''

print '''\nA. Define a string variable, story, to hold the
content of the story including its layout. (5 points)'''
story = '''
Once upon a time, deep in an ancient
jungle, there lived a tiger.  This tiger
liked to eat fish, but the jungle had
very little fish to offer.  One day, an
explorer found the tiger and discovered
it liked fish.  The explorer took the
tiger back to NYC, where it could
eat as much fish as it wanted.  However,
the tiger became homesick, so the
explorer brought it back to the jungle,
leaving a large supply of fish.

-- The End of the Story --
'''
print 'The original story is as follows:'
print story

print '\nB. Replace the words "tiger" and "fish" with the format symbol %s. (10 points)'
story = story.replace('tiger', '%s')
story = story.replace('fish', '%s')
print 'Display the story to see if you have made a format string:'
print story

print '''\nC. Create a tuple, t1, to hold the words of "tiger"
and "fish" to restore the story to its original condition by
using the format operator (%). (10 points)'''
t1 = ('tiger', 'tiger', 'fish', 'fish', 'tiger', 'fish', 'tiger', 'fish', 'tiger', 'fish')
story = story % t1
print '\nThe original story has been restored using the format operator:'
print story

print '''\nD. Programmatically create a different version of the story by
changing the animal and its food from "tiger" and "fish" to "monkey"
and "bananas." (15 points)'''
story = story.replace('tiger', '%s')
story = story.replace('fish', '%s')
t2 = ('monkey', 'monkey', 'bananas', 'bananas', 'monkey', 'bananas', 'monkey', 'bananas', 'monkey', 'bananas')
story = story % t2
print story


print '\n\n***** Question 2 *****'

print '''\nThis program is to use a format string and a
dictionary to format and change a story. '''

print '''\nA. Replace the word "monkey" with "%(animal)s"
"bananas" with "%(food)s", and NYC with "%(city)s". (10 points)'''
story = story.replace('monkey', '%(animal)s')
story = story.replace('bananas', '%(food)s')
story = story.replace('NYC', '%(city)s')
print 'The story became the following format string:'
print story

print '\nB. Define a dictionary to hold some keys and values (10 points)'
myDict = {'animal':'cat', 'food':'mice', 'city':'Beijing'}
print 'The dictionary is:', myDict
print 'The story after the dictionary was applied to the format string:'
print story % myDict

print '\nC. Update the dictionary values with "fox", "rabbit", and "London" (10 points)'
myDict['animal'] = 'fox'
myDict['food'] = 'rabbit'
myDict['city'] = 'London'
print 'The updated dictionary is:', myDict
print 'The new version of the story after the dictionary was applied to the format string:'
print story % myDict


print '\n\n***** Question 3 *****'

print '''\nThis program is to use lists to calculate
the dot product of two n-vectors. (10 points)'''
u = [[10],[-2],[3],[44]]
v = [[20],[3],[-2],[11]]
dotProduct = u[0][0]*v[0][0]+u[1][0]*v[1][0]+\
             u[2][0]*v[2][0]+u[3][0]*v[3][0]
print 'The list representation of vector u is ' + str(u) + '.'
print 'The list representation of vector v is ' + str(v) + '.'
print 'The dot product of uv is ' + str(dotProduct) + '.'
print '\n***** The End of HW1 *****'
print




