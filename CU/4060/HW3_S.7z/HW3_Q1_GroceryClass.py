'''
This solution is coded by Dr. Xiaolong Yang. All rights are reserved. It is provided
to the student in STSCI 4060 class at Cornell University as a solution for educational
purpose. No part of this solution can be sold or given to anyone or entity without
a written permission from the author.
'''
import time

class Grocery:
    #class constructor
    def __init__(self):    
        self.inventory=dict()

    #insert or items to the inventory dictionary or update the disctionary
    #In: a new dictionary item
    #Result: update inventory dictionary
    def buildInventory(self, newItems): 
        self.inventory.update(newItems)

    #dispaly the items in the inventory dictionary
    def viewInventory(self):
        if self.inventory == {}:
            print "The inventory is empty. Put an order ASAP."
        else:
            print self.inventory.items()
        
    #process the check out activities and print the invoice
    #mode of process: interactive
    #result: print out an invoice if any item was sold or print "Goodbye."
    def checkOut(self):
        total=0
        subtotal=0
        buy=False
        bought=dict()
        a=raw_input('Do you want to buy something? ')
        if a in ['Yes','yes','Y','y']:
            buy=True
        while buy:   
            item=raw_input('Enter an item to buy: ')
            if item.upper() in self.inventory.keys() and self.inventory[item][0]>0:
                num=input('How many do you want? ')
                if num <= self.inventory[item][0]:
                    subtotal=self.inventory[item][1]*num
                    total+=subtotal
                    self.inventory[item][0] -= num
                    bought[item]=[num, self.inventory[item][1], subtotal]
                else:
                    print 'Not enough in stock; we can only sell you %s item(s).' % self.inventory[item][0]
                    subtotal=self.inventory[item][1]*self.inventory[item][0]
                    total+=subtotal
                    bought[item]=[self.inventory[item][0], subtotal]
                    self.inventory[item][0] = 0
                    
            else:
                print "Wrong item name or out of stock."
                
            a=raw_input('Do you still want to buy something? ')
            if a in ['Yes','yes','Y','y']:
                buy=True
            else:
                buy=False
                
        if bought != {}:
            print '\nItem\t\tQuantity\t\tPrice\tSubtotal'
            print '-------------------------------------------------'
            for aKey in bought:
                print '%s\t\t%s\t\t%.2f\t%.2f' %(aKey, bought[aKey][0], bought[aKey][1], bought[aKey][2])
            print '-------------------------------------------------'
            print 'Please pay $%.2f\n' % total

        print "Goodbye.  " + time.asctime() + "\n"    
    

