'''
This solution is coded by Dr. Xiaolong Yang. All rights are reserved. It is provided
to the student in STSCI 4060 class at Cornell University as a solution for educational
purpose. No part of this solution can be sold or given to anyone or entity without
a written permission from the author.
'''

from node import Node 
class LinkedList:
    
    def __init__(self):  #constructor
        self.head = None
    
    def isEmpty(self):   #check if the list is empty
        return self.head == None
    
    def add(self,element):#add an element
        temp = Node(element)
        temp.setNext(self.head)
        self.head = temp
    
    def size(self): #return the number of the nodes in the list
        current = self.head
        count = 0
        while current != None:
            count = count + 1
            current = current.getNext()
        
        return count
    

    #search the list to see if an element is in the list
    #In: element
    #Out: True if found, or False if not found
    def search(self,element): 
        current = self.head
        found = False
        while current != None and not found:
            if current.getData() == element:
                found = True
            else:
                current = current.getNext()
        
        return found
    
    #Remove an element (if exist) from a list
    #In: element
    #Out: Removed element
    def remove(self,element):
        current = self.head
        previous = None
        found = False
        while not found:
            if current.getData() == element:
                found = True
            else:
                previous = current
                current = current.getNext()
        
        if previous == None:
            self.head = current.getNext()
        else:
            previous.setNext(current.getNext())
        return current.data



    '''****************************************** '''
    #Below are the new methods HW3 needs to add.
    
    #Add a method called printList() so that
    #you can print (i.e., display)all the
    #values of the linked list elements from
    #the first one to the last one.
    
    def printList(self):
        node = self.head
        lst=[]

        while node != None:
            lst.append(node.data)
            node = node.next
        print lst

    
    '''
    Add findAll(element)method to the number of times
    of a given element appears in the linked list
    and at what index(es) the element appears. If
    the given element does not exist in the list, the
    method displays "element was not found," where
    "element" is the given element. For example,
    if you want to find how many times 500 appears in
    a linked list (whose values are [600, 500, 500,
    400, 500, 300, 200, 100, 500]), findAll(500)
    should display " 500 is found 4 time(s)
    at position(s) [1, 2, 4, 8]. "
    '''
    def findAll(self,element):
        current = self.head
        size=self.size()
        num=0
        pos=-1
        rl=[]
        found = False
        while current != None:
            pos+=1
            if current.getData() == element:
                found = True
                num+=1
                rl.append(pos)
                current = current.getNext()
            else:
                current = current.getNext()
        
        if found:
            print "%s is found %s time(s) at poistion(s) %s." %(element, num, str(rl))
        else:
            print "%s was not found." % element
    

    '''
    Add a method called insert(position, element)
    to insert an element at the specified position
    (i.e., the index of the list displayed by the
    printList() method).
    '''
    def insert(self, position, item):
        if position == 0:
            self.add(item)
        elif position > self.size():
            print("position index out of range")
        elif position == self.size():
            self.appendLast(item)
        else:
            temp = Node(item)
            current = self.head
            previous = None
            psn=0
            while psn != position:
                previous = current
                current = current.next
                psn+=1
            previous.next = temp
            temp.next = current

    '''
    Add a method called popAtIndex(index) to
    remove the element at the specified
    index and return the value of the popped
    list element.
    '''
    def popAtIndex(self, index):
        if index > self.size()-1:
            print("position index out of range")
        else:
            prev = None
            cur = self.head
            i = 0
            
            while (cur != None) and (i < index):
                prev = cur
                cur = cur.next
                i += 1

            if prev == None:
                self.head = cur.next
            else:
                prev.next = cur.next
        return cur.data

    '''
    Add a method called appendLast(element)
    to append a new element to the end of the
    linked list.
    '''
    def appendLast(self, data):
        new_node = Node(data)
        current = self.head
        previous = None

        if self.head == None:
            self.head = new_node

        else:
            while current != None:
                previous = current
                current = current.getNext()
            previous.setNext(new_node)





    



                    

            


