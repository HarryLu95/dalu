'''
This solution is coded by Dr. Xiaolong Yang. All rights are reserved. It is provided
to the student in STSCI 4060 class at Cornell University as a solution for educational
purpose. No part of this solution can be sold or given to anyone or entity without
a written permission from the author.
'''

'''
write a Python program named linkedListTest.py
to test all the methods (old and new) to show
that updated LinkedList class works correctly.
For each test, add a comment to document what
the test is and output the result. For example,
after inserting 666 to [100, 200, 300, 400] at
index 2, you should output " After inserting
666 to the list at index 2, the list becomes
[100, 200, 666, 300, 400]."
'''

from HW3_Q2_linkedlist import LinkedList

#create an object called l from the LinkedList class
l=LinkedList()

#test isEmpty()
if l.isEmpty():
    print 'At the very beginning, the linked list is empty.'

#test add(element) by adding the following elements
l.add(100)
l.add(200)
l.add(300)
l.add(400)
l.add(500)
l.add(600)
print "Six elements (100, 200, 300, 400, 500, and 600) have been added to the list."

#test size()
print 'Now the size of the linked list is %s.' % l.size()

#test search
if l.search(200):
    print 'The element 200 was found in the linked list.'

#test remove(element) and printList()
print 'Now the linked list, from the beginng to the end, contains:'
l.printList()
l.remove(300)
print 'After element 300 was removed from the linked list, now the list is:'
l.printList()

#test insert(position, element)
l.insert(4, 500)
print 'After element 500 was inserted at index 4, the list becomes:'
l.printList()

#test findAll(element)
l.findAll(500)

#test popAtIndex(index)
l.popAtIndex(2)
print 'After the element at index 2 was popped, the list becomes:'
l.printList()

#test appendLast(element)
l.appendLast(800)
print 'After the new element 800 was appended the end, the list becomes:'
l.printList()


