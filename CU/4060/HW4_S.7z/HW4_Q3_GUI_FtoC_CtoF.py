''' convert_gui1.pyw
This program converts Fahrenheit to Celsius using a simple
graphical interface.''' 

from graphics import *
def main():
    win = GraphWin("Temperature Converter", 300, 200)
    win.setCoords(0.0, 0.0, 300.0, 200.0)

    # Draw the interface
    Text(Point(90,150), " Celsius Temperature:").draw(win)
    Text(Point(105,100), "Fahrenheit Temperature:").draw(win)
    inputC = Entry(Point(210,150), 5)
    inputC.setText("")
    inputC.draw(win)
    inputF = Entry(Point(218,100),5)
    inputF.setText("")
    inputF.draw(win)
    rect=Rectangle(Point(100,20), Point(200,70))
    rect.setOutline('red')
    rect.setFill('yellow')
    rect.draw(win)
    button = Text(Point(150,45),"Convert It")
    button.draw(win)

    # wait for a mouse click
    #win.getMouse()
    #x=whatBox.getX()
    #y=whatBox.getY()

    # wait for a mouse click on the button
    while True:
        c=win.getMouse()
        x=c.getX()
        y=c.getY()
        if (x>=100 and x<=200) and (y>=20 and y<=70):
            break

    if inputC.getText()!="":
        celsius = eval(inputC.getText())
        fahrenheit = 9.0/5.0 * celsius + 32
        # display output and change button
        inputF.setText("%0.1f" % fahrenheit)
        button.setText("Quit")
    elif inputF.getText()!="":
        fahrenheit = eval(inputF.getText())
        celsius= (fahrenheit-32)*5.0/9.0 
        # display output and change button
        inputC.setText("%0.1f" % celsius)
        button.setText("Quit")
    else:
        print 'Try again and enter a temperature.'
    
    # wait for click and then quit
    while True:
        p=win.getMouse()
        x=p.getX()
        y=p.getY()
        if (x>=100 and x<=200) and (y>=20 and y<=70):
            break
    win.close()
            

main()

