'''
HW4 Question 2 (55 points)
Draw an automatic sacle bar chart of investment.
'''

from graphics import *
import random, math

def main():
    print 'Ploting the growth of a 10-year investment.'

    #get principal and interest rate
    principal = input('Enter initial principal: ')
    apr = input('Enter annualized interest rate: ')

    #get some values for creating auto legends of the Y-axis
    amount10years = principal*math.pow(1+apr, 10)
    #use 200 pixels for max bar height; distance of Y-axis label is 50 pixels
    pixelPerDollar = 200/amount10years 
    kiloDollarPerUnit=round(amount10years/1000, 1)

    #create a graphic window with auto legends on the left edge
    win = GraphWin('Investment Growth Chart', 330, 260)
    win.setCoords(0,0,330,260)
    win.setBackground('white')
    for i in range(5):
        lbl=Text(Point(28,30+i*50), str(i*kiloDollarPerUnit)+'K')
        lbl.setSize(8)
        lbl.draw(win)
        
    #to draw the X-axis lengends
    #leave some pixels at top and bottom (this top margin is optional;
    #it is OK as long as the whole chart fits in the graphic window
    #and scales properly with the total amount of money)
    for i in range(0,11):
        lbl7=Text(Point(50+i*25,23),  str(i))
        lbl7.setSize(8)
        lbl7.draw(win)

    lbl8=Text(Point(159,13), 'Year')
    lbl8.setSize(8)
    lbl8.draw(win)
    aline=Line(Point(6,30), Point(6,255))
    aline.draw(win)

    #draw bars for successive years
    for year in range(11):
        #calculate value for the next year
        amount = principal*math.pow(1+apr,year)
        #draw for this value
        xl=year*25+40
        height = amount*pixelPerDollar
        bar=Rectangle(Point(xl, 30),Point(xl+25, 30+height))
        r = random.randrange(256)
        b = random.randrange(256)
        g = random.randrange(256)
        color = color_rgb(r, g, b)
        bar.setFill(color)
        bar.draw(win)

    raw_input('Press <Enter> to quit')
    win.close()

main()

