'''
HW4 Question 1      (20 points)
Making a scatter plot
'''

from graphics import *

infile=file('C:\Python27\Ref\Teaching\Spring2019\STSCI4060Spring2019\HW\HW4\\unequal.txt', 'r')
win=GraphWin('Scat Plot', 800,700)
win.setCoords(-100,-300,700,400)
win.setBackground('black')

for line in infile:
        twoNum=line.split()
        p=Point(float(twoNum[1])*50,float(twoNum[2])*50)
        if float(twoNum[0])==1:
            p.setFill('red')
        elif float(twoNum[0])==2:
            p.setFill('yellow')
        elif float(twoNum[0])==3:
             p.setFill('green')
        p.draw(win)
        
textLoc=Point(350,370)
label=Text(textLoc,'Click a place to put your label')
label.setFill('white')
label.draw(win)

aPoint=win.getMouse()
myLabel=Text(aPoint, 'Produced by Xiaolong Yang')
myLabel.setFill('white')
myLabel.draw(win)
label.undraw()

win.getMouse()
win.close()

