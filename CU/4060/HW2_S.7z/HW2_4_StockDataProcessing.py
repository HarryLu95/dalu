'''
HW2, Question 4
From the data file stock.txt, create a dictionary, myDict, containing
four keys: stockNames, dates, openPrices and closePrices,and then
from myDict find out the stock names that increased their prices on
that day. 
'''
#Creat an object f by reading the stock.txt file using file()
f=file("C:\Users\\xy44\Dropbox\Bottle\\stock.txt")

#Define some lists to hold the contents from the file
keys=['stockNames','dates','openPrices','closePrices']
names=[]
dates=[]
openPrices=[]
closePrices=[]

#Populate the lists by spliting the lines
for aa in f:
	item = aa.split('\t')
	names.append(item[0])
	dates.append(item[1])
	openPrices.append(item[2])
	closePrices.append(item[5])
f.close()

#Display the lists
print 'The list names is:'
print names
print #Create a blank line
print 'The list dates is:'
print dates
print
print 'The list openPrices is:'
print openPrices
print
print 'The list closePrices is:'
print closePrices
print

#Create myDict using two built-in functions zip() and dict()
myDict=dict(zip(keys, [names,dates,openPrices,closePrices]))
print 'myDict dictionary is:'
print myDict

#Find out the stocks that increased their prices on the day of trade
increaseStock=[]
for i in range(len(names)):
    if float(myDict['openPrices'][i]) < float(myDict['closePrices'][i]):
        increaseStock.append(names[i])

p='' #An empty string to hold the content to print out

for a in increaseStock:
    p=p+a+', '
print '\nThe stocks that increased their prices are ' + p[:-2] +'.'





