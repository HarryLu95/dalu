'''
STSCI 4060 HW2
Question 2

This program is to count the number of lines, words, characters, and paragraphs
of a text file.
'''

infile = file('C:\Python27\Ref\Teaching\Spring2018\STSCI4060Spring2018\HW\HW2\AboutCornell.txt')

#define and initialize some variables
#lineNum: number of lines, wordNum: number of words; charNum: number of characters
#paraNum: number of paragraphs
lineNum=wordNum=charNum=0 
paraNum=1
atl=''
for aline in infile:
    atl=atl + aline
    lineNum+=1
    lineWords=aline.split()
    if len(lineWords)==0:
        paraNum+=1
    for aWord in lineWords:
        wordNum+=1
        charNum+=len(aWord)
        
atl
print "\nIn the article there are %s lines, %s words, %s characters (excluding whitespaces) \
and %s paragraphs." % (lineNum, wordNum, charNum, paraNum), '\n'
