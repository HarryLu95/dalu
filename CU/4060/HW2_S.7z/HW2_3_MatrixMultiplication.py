'''
STSCI 4060 HW2, Question 3
Multiplication of two matrixes of arbitrary dimensions
'''

# Return the result of multiplication of matrixes A and B. If the dimentions
# do not match,output an error message and return an empty matrix.
def matrixMultiplication(A,B):
    colNumA=len(A[0])   #number of columns of matrix A
    rowNumA=len(A)      #number of rows of matrix A
    colNumB=len(B[0])   #number of columns of matrix B
    rowNumB=len(B)      #number of rows of matrix B

    if colNumA!=rowNumB:
        print '\nError, these two matrixes cannot be multiplied since their'
        print 'sizes do not match. Enter two different matrixes again.'
        return []
    else:
        C=[[0 for row in range(colNumB)] for column in range(rowNumA)]
        
        for i in range(rowNumA):
            for j in range(colNumB):
                for k in range(colNumA):
                    C[i][j] += A[i][k]*B[k][j]
        return C


def main():
   print '\nPlease input two matrixes A and B to multiply'
   A=input('Input Matrix A: ')
   B=input('Input Matrix B: ')
   C = matrixMultiplication(A,B) 
   if C!=[]:
       print '\nMatrix A is:'
       for itemA in A:
           print itemA
       print '\nMatrix B is:'
       for itemB in B:
           print itemB
       print '\nMatrix C = AB is:'
       for itemC in C:
           print itemC
   else: main()

main()

