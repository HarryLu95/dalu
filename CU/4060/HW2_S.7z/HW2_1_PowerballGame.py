'''STSCI 4060 HW2, Question 1
This program is to imitate the Power Ball game.'''

import random

raw_input('\nPlay a PowerBall game by pressing <Enter>. Good Luck! ')
powerBallGame=list()  #create a list to hold all the balls
L=range(1,60)
powerBallGame=random.sample(L,5) #select 5 white ball w/o replacement
powerBallGame.append(random.randrange(1,36)) #select the red power ball
theResult=''

#to produce a string for printing out the required format of the 6 numbers
for item in powerBallGame:
    theResult=theResult+' '+ str(item)
    
print '\nYour PowerBall Game result is:\n\n', theResult, '\n'

